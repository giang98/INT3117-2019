<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Chng I S HNH THNH TRT T TH GII MI SAU CHIN TRANH TH GII TH HAI (1945 - 1949)</name>
   <tag></tag>
   <elementGuidId>f9d86323-59b3-4fa8-afd6-4d563716e4d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='LỊCH SỬ THẾ GIỚI HIỆN ĐẠI TỪ NĂM 1945 ĐẾN NĂM 2000'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>item-file</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Chương I. SỰ HÌNH THÀNH TRẬT TỰ THẾ GIỚI MỚI SAU CHIẾN TRANH THẾ GIỚI THỨ HAI (1945 - 1949) </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chương I. SỰ HÌNH THÀNH TRẬT TỰ THẾ GIỚI MỚI SAU CHIẾN TRANH THẾ GIỚI THỨ HAI (1945 - 1949) </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/app-root[1]/div[@class=&quot;content-bound&quot;]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-12 main-content fullscreen&quot;]/question[1]/div[@class=&quot;row&quot;]/div[@class=&quot;border-right sidebar d-print-none open mobile-closed&quot;]/div[@class=&quot;scroll-question pb-3&quot;]/tree-index[@class=&quot;first-children&quot;]/ul[@class=&quot;all-item&quot;]/li[@class=&quot;children-item&quot;]/tree-index[1]/ul[@class=&quot;all-item&quot;]/li[@class=&quot;children-item&quot;]/tree-index[1]/ul[@class=&quot;all-item&quot;]/li[@class=&quot;children-item&quot;]/div[@class=&quot;item-content d-flex&quot;]/div[@class=&quot;w-90&quot;]/div[@class=&quot;item-text d-inline-block&quot;]/span[@class=&quot;item-file&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LỊCH SỬ THẾ GIỚI HIỆN ĐẠI TỪ NĂM 1945 ĐẾN NĂM 2000'])[1]/following::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chương II. LIÊN XÔ VÀ CÁC NƯỚC ĐÔNG ÂU (1945 - 1991). LIÊN BANG NGA (1991 - 2000)'])[1]/preceding::span[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//li[4]/tree-index/ul/li/div/div/div/span</value>
   </webElementXpaths>
</WebElementEntity>

<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Issue tests</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-10-09T17:27:30</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>0c071e44-c30c-46a8-9063-e68816294632</testSuiteGuid>
   <testCaseLink>
      <guid>47a37b05-bda1-49d7-b5d2-aa2fa71c02f8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue/Get issue/Get an issue by Key - 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d18133d7-c981-46d1-b3ca-dc40dbd667b8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue/Get issue/Get an issue by Key - 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c98ab1e5-2426-4c5f-a7e4-bb647335585f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue/Edit issue/Edit an existing issue by Key</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>42cd1531-f391-4489-82eb-d83f8e67a606</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Simple examples/api-2-issue/Create issue/Create a new issue</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e527cfa2-cfbd-47a4-80ec-892d2743a62f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Advance examples/api-2-issue/Get issue/Get an issue by Key</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bac558f2-7a16-4360-a59c-1be4c5c39bd0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Advance examples/api-2-issue/Edit issue/Edit an existing issue by Key</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>73a5f8a3-4468-4ecc-bc78-a1523ac10f8b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/REST examples/Advance examples/api-2-issue/Create issue/Create a new issue</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
